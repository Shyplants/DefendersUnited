// Fill out your copyright notice in the Description page of Project Settings.


#include "AEnumClass.h"

AEnumClass::AEnumClass()
{
}

AEnumClass::~AEnumClass()
{
}
